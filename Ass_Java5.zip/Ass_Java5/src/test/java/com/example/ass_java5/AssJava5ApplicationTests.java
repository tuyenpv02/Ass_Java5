package com.example.ass_java5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssJava5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
